Helper for writing command-line applications in Perl.
